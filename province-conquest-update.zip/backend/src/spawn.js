/**
 * Castle placement from the baked map (public/map.json): the same SpawnPlanner and
 * province blocking the old dev server used, so castles never land on mountains,
 * water, other castles or province capitals.
 */
import fs from 'fs';
import path from 'path';
import { SpawnPlanner, makeRng } from '../../runtime/SpawnPlanner.js';
import { buildProvinces, blockCapitalFootprints } from '../../runtime/ProvinceMap.js';
import { PROVINCE_CONFIG, PROVINCES_PER_CIV, PROVINCE_NAMES } from '../../runtime/provinces.js';
import { CIVILIZATIONS, civById, randomName } from '../../runtime/civilizations.js';
import { httpError } from './httpError.js';

export function createMapSpawner({ root, publicDir = 'public', seed = 1337, npcPerCiv = 3 }) {
  const PUBLIC = path.resolve(root, publicDir);
  const manifestPath = path.join(PUBLIC, 'map.json');
  let cache = null; // { mtime, planner }

  function mapKey() {
    try { return String(fs.statSync(manifestPath).mtimeMs); } catch { return null; }
  }

  function load() {
    const key = mapKey();
    if (!key) throw httpError(503, 'No baked map found (public/map.json). Bake the map in the editor first.');
    if (cache && cache.key === key) return cache;
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const bin = (d) => new Uint8Array(fs.readFileSync(path.join(PUBLIC, d.file)));
    const { width: gw, height: gh } = manifest.grid;
    const collision = bin(manifest.data.collision);
    const territory = bin(manifest.data.territory);
    const { provinces, grid } = buildProvinces(
      { width: gw, height: gh, territory, collision, objects: manifest.objects ?? [] },
      { civCount: CIVILIZATIONS.length, perCiv: PROVINCES_PER_CIV, sectionCount: 6, startAngleDeg: 0, config: PROVINCE_CONFIG }
    );
    blockCapitalFootprints(collision, gw, gh, provinces, PROVINCE_CONFIG.capitalFootprintRadiusTiles);
    const planner = new SpawnPlanner({ width: gw, height: gh, collision, territory, objects: manifest.objects ?? [] });
    cache = { key, planner, provinces, grid, gw, gh };
    return cache;
  }

  return {
    mapKey,
    /** The provinces (id, biome, name, capital tile) and which ones touch each other: for the Province Conquest event. */
    provinces() {
      const c = load();
      if (!c.provinceInfo) {
        const nb = new Map(c.provinces.map((p) => [p.id, new Set()]));
        const { grid, gw, gh } = c;
        for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
          const a = grid[y * gw + x]; if (a === 255) continue;
          if (x + 1 < gw) { const b = grid[y * gw + x + 1]; if (b !== 255 && b !== a) { nb.get(a)?.add(b); nb.get(b)?.add(a); } }
          if (y + 1 < gh) { const b = grid[(y + 1) * gw + x]; if (b !== 255 && b !== a) { nb.get(a)?.add(b); nb.get(b)?.add(a); } }
        }
        c.provinceInfo = { provinces: c.provinces.map((p) => { const civ = CIVILIZATIONS[p.civIndex]; return { id: p.id, civId: civ.id, local: p.local, name: PROVINCE_NAMES[civ.id]?.[p.local] ?? `${civ.name} ${p.local + 1}`, capital: { tileX: p.capital.tileX, tileY: p.capital.tileY }, neighbors: [...nb.get(p.id)] }; }) };
      }
      return c.provinceInfo;
    },
    /** @param placed castles that already exist ({tileX, tileY}) */
    pickSpot(civId, placed) {
      const { planner } = load();
      const civ = civById(civId);
      if (!civ) throw httpError(400, 'unknown civilization');
      return planner.pickSpot(civ.territory, Math.random, placed) ?? planner.pickSpot(null, Math.random, placed) ?? null;
    },
    /** A random good spot anywhere (not in the neutral area), away from `placed` things. Used for NPC camps. */
    pickAnySpot(placed) {
      const { planner } = load();
      return planner.pickSpot(null, Math.random, placed) ?? null;
    },
    makeNpcs() {
      const { planner } = load();
      const rand = makeRng(seed);
      const placed = [];
      const taken = new Set();
      const npcs = [];
      for (const civ of CIVILIZATIONS) {
        for (let i = 0; i < npcPerCiv; i++) {
          const spot = planner.pickSpot(civ.territory, rand, placed);
          if (!spot) break;
          const name = randomName(civ.id, rand, taken);
          taken.add(name.toLowerCase());
          const npc = { key: `npc_${civ.id}_${i}`, name, civId: civ.id, tileX: spot.tileX, tileY: spot.tileY };
          placed.push(npc);
          npcs.push(npc);
        }
      }
      return npcs;
    },
  };
}
