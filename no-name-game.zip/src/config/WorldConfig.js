/**
 * WorldConfig
 * -----------
 * Single source of truth for all world/grid/tile/chunk constants.
 * Nothing else in the codebase should hardcode these numbers.
 */
import { BiomeId } from '../world/BiomeRegistry.js';

export const WorldConfig = {
  // Deterministic generation seed. Change this to get a different world.
  seed: 1337,

  // Logical grid — used ONLY for gameplay (pathfinding, building placement).
  gridWidth: 600,
  gridHeight: 600,

  // Logical chunk — the gameplay/streaming unit. Kept large so pathfinding
  // and building-placement bookkeeping stays simple and coarse-grained.
  logicalChunkSize: 32, // 32x32 logical tiles per logical chunk

  // Isometric tile dimensions (visual space, not logical space).
  tileWidth: 128,
  tileHeight: 64,

  // A logical chunk's visual footprint (4096x2048 at current tile size) is
  // too large to safely rasterize into a single GPU texture, especially on
  // mid-range mobile hardware (exceeds comfortable MAX_TEXTURE_SIZE budgets
  // and costs ~32MB VRAM per texture at RGBA8).
  //
  // So the VISUAL layer subdivides each logical chunk into smaller
  // "render tiles" that each get their own RenderTexture. This is purely
  // a rendering-side subdivision — it does not affect the logical grid,
  // pathfinding, or building placement in any way.
  //
  // 32 / 16 = each logical chunk becomes a 2x2 grid of render tiles.
  renderTileSize: 16, // 16x16 logical tiles per render tile

  // How many render tiles (in each direction) to keep loaded beyond the
  // camera viewport, to avoid visible pop-in while panning.
  streamingBufferTiles: 1,

  // ---- Civilization territories -----------------------------------------
  // Single shared source for BOTH the outer mountain dividers
  // (MountainRingGenerator.generateRadialDividers, via TerrainDemoScene)
  // AND the biome-color territory lookup (TerritoryMap + BiomeMap) — so a
  // territory's color boundary is structurally guaranteed to line up with
  // its actual mountain-wall boundary, instead of two independently-tuned
  // configs drifting apart. centerTileX/Y are computed below (they just
  // mirror gridWidth/gridHeight/2, no need to duplicate the literal here).
  territories: {
    sectionCount: 6,
    startAngleDeg: 0,
    // Below this radius (tiles from map center) is the shared neutral
    // zone (plain grass) — should sit just past the inner mountain ring's
    // own radius so the two don't overlap. See TerrainDemoScene.
    innerRadiusTiles: 55,
    // Colors were sampled from the six civilization map images
    // (see BiomeRegistry).
    sectionBiomeIds: [BiomeId.PERSIA, BiomeId.STEPPE, BiomeId.ARABIA, BiomeId.JAPAN, BiomeId.ROME, BiomeId.VIKING],
    sectionNames: ['Persia', 'Mongol Steppe', 'Arabia', 'Japan', 'Rome', 'Viking'],
    // Starting tree density (0..1) per territory, same order as sectionNames,
    // and for the neutral center. Dry regions get few trees. Only a default:
    // the Forests panel sliders override it live.
    treeDensity: [0.8, 0.55, 0.3, 1.0, 1.0, 1.0],
    // Center of the map: no trees at all.
    neutralTreeDensity: 0,
  },
};

// Derived constants (computed once, not re-derived ad hoc elsewhere).
WorldConfig.renderTilesPerChunkAxis =
  WorldConfig.logicalChunkSize / WorldConfig.renderTileSize;

WorldConfig.renderTilePixelWidth =
  WorldConfig.renderTileSize * WorldConfig.tileWidth; // sum of half-diagonals, see TerrainRenderTile
